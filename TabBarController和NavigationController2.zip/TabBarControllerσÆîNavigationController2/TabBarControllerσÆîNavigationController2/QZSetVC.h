//
//  QZSetVC.h
//  TabBarController和NavigationController2
//
//  Created by 蓝科 on 16/5/27.
//  Copyright © 2016年 范庆忠. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QZSetVC : UIViewController

@end
